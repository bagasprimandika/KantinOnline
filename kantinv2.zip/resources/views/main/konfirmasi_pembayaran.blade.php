@extends('layouts.shop')

@section('content')
    <!-- Breadcrumb Section Begin -->
    <section class="breadcrumb-section set-bg st-color container">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <div class="breadcrumb__text">
                        <h2>Konfirmasi Pesanan</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Breadcrumb Section End -->

    <!-- Checkout Section Begin -->
    <section class="checkout spad">
        <div class="container">
            <div class="checkout__form">
                <h4>Detail Pesanan</h4>
                <div class="row">
                    <div class="col-lg-8 col-md-6">
                        <div class="form-group mb-4">
                            <label for="no_pesanan">Nomor Pesanan</label>
                            <input type="text" class="form-control" id="no_pesanan" value="{{ $pesanan->no_pesanan }}"
                                disabled>
                        </div>

                        <button id="pay-button" class="btn site-btn float-right">BAYAR SEKARANG</button>
                        <a href="/shop" class="btn site-btn text-dark border border-secondary"
                            style="background-color: white;">SHOP</a>
                    </div>
                    <div class="col-lg-4 col-md-6">
                        <div class="checkout__order">
                            <h4>Detail Pesanan</h4>
                            <div class="checkout__order__products">Items <span>Total</span></div>
                            <ul>
                                @foreach ($items as $item)
                                    <li>{{ $item->produk->nama_produk . ' (x' . $item->qty . ')' }}
                                        <span>Rp. {{ number_format($item->subtotal, 0, ',', '.') }}</span>
                                    </li>
                                @endforeach
                            </ul>
                            <div class="checkout__order__subtotal">Subtotal <span>Rp.
                                    {{ number_format($pesanan->subtotal, 0, ',', '.') }}</span></div>
                            <div class="checkout__order__subtotal mt-n3">Ongkir <span id="ongkir">Rp.
                                    {{ number_format($pesanan->ongkir, 0, ',', '.') }}</span></div>
                            <div class="checkout__order__total">Total <span id="total">Rp.
                                    {{ number_format($pesanan->total, 0, ',', '.') }}</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Checkout Section End -->

    <!-- Midtrans Snap -->
    <script src="https://app.midtrans.com/snap/snap.js" data-client-key="{{ env('MIDTRANS_CLIENT_KEY') }}"></script>
    <script type="text/javascript">
        document.getElementById('pay-button').addEventListener('click', function() {
            window.snap.pay('{{ $pesanan }}', {
                onSuccess: function(result) {
                    alert("Pembayaran berhasil!");
                    window.location.href = "/main/home"; // redirect ke halaman sukses
                },
                onPending: function(result) {
                    alert("Menunggu pembayaran...");
                },
                onError: function(result) {
                    alert("Pembayaran gagal!");
                },
                onClose: function() {
                    alert("Anda menutup popup tanpa menyelesaikan pembayaran");
                }
            });
        });
    </script>
@endsection
